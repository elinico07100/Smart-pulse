import socket

# Crea un socket UDP que escuche en el puerto 3333
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(("", 3333))

print("Escuchando datos de pulso en UDP puerto 3333…")
while True:
    data, addr = sock.recvfrom(64)        # recibe paquete
    valor = data.decode().strip()         # convierte a texto
    print(f"{addr[0]} → {valor}")         # muestra IP y lectura
