import serial
import time

# Reemplazá 'COM3' por el puerto real de tu Arduino
# En Windows suele ser COM3, COM4... En Linux/Mac: /dev/ttyUSB0 o /dev/ttyACM0
arduino = serial.Serial('COM5', 9600)  # <-- CAMBIÁ SI ES OTRO PUERTO
time.sleep(2)  # Esperar a que se estabilice la conexión

# Abrimos archivo CSV para escribir
with open("tiempos_pasos.csv", "w") as archivo:
    archivo.write("Tiempo\n")  # Encabezado CSV

    print("⏱ Escuchando pasos desde Arduino...")
    while True:
        if arduino.in_waiting > 0:
            linea = arduino.readline().decode('utf-8').strip()
            print("Registrado:", linea)
            archivo.write(linea + "\n")